# -*- coding: gb2312 -*-
import scrapy
import re
import requests
from Xyeyy.items import XyeyyItem

class XyeyySpider(scrapy.Spider):
    name = 'xyeyy'

    def start_requests(self):
        url = 'http://www.xyeyy.com'
        yield scrapy.Request(url)

    def parse(self, response):
        item = XyeyyItem()

        #   ��Ҫ��������cookie����cookie���Բ������ٶ���ȡ������cookie��Ч����һ�����ң���ʱ��Ҫ�ֶ�����cookie��
        headers = {
            'cookie': "FSSBBIl1UgzbN7N80S=shoB.AhvGrz.EloMHBYBEnIjvmL_MUKi9dBoRTfu24w5_SQ4AIYHPBJw1r.wVqbf; 8E7193D63A972E529CDCB5D81FB06BC8=692bf679-2551-4851-b693-703e2520f9bf; FSSBBIl1UgzbN7N80T=37wOWCO7Hdv9mMT.12uJxX0Tf2afui0Tuh7Gc4QhMprzPvcnyQFnaH4L7qeYHtUfrez8Yq7ftSEQpKj_P3jwAXWj27FgMngGIv1xS8G_pX1l1IT1OektdX1zqd0ZojdGlJczM11sGtaMqTrqiR27LWe1kb3BUFt5YyRBOlGZHlEz6V60R3x1oEbmAAAxT1vNDyqotB7S0Hl6_9QtHa1a8g1jcMiEnNI91aJZgJJAX1gwCly.3MY5Z1WM9ZOsa2zKfXgVv7bVsS2nEopN7Zq7kcZGVjZRsOjHrOgAXmakjlFfU1pQpD1ycmO6gylumNIETzjG50N8BMBkvyFa8wvGyoxsBd1h9YCiiLNw_.KUGlUFg2a",
            'cache-control': "no-cache",
            'postman-token': "f7e8855e-4a43-f312-7a8a-c931dfe66c14"
        }
        first_url = 'http://www.xyeyy.com/3/29/index.htm'
        r = requests.request("GET", first_url, headers=headers)
        #   ��ȡ�б깫�������
        total = int(''.join(re.findall(r'\xb9\xb2(\d+)\xcc\xf5', r.text)))

        #   ���������б��б�ҳ������
        start_urls = []
        for i in range(0, total, 15):
            start_urls.append('http://www.xyeyy.com/3/29/index.jsp?pager.offset='+str(i)+'&pager.desc=false')
        for u in start_urls:
            response = requests.request("GET", u, headers=headers)
            s = response.text
            url_list = re.findall(r'<a href=\'(http://www.xyeyy.com/3/29/content_\d+\.html)', s)
            for i in range(len(url_list)):

                #   ��������ҳ�� ��ȡҳ������
                response1 = requests.request("GET", url_list[i], headers=headers)
                s1 = response1.text
                item['detail_url'] = url_list[i]
                try:
                    title = re.findall(r'<title>(.*)</title>', s1)
                    title1 = re.findall(r'<div class="article">(.*)</div>', s1)
                    if title:
                        item['title'] = ''.join(title).encode('latin1').decode('gbk')
                    elif title1:
                        item['title'] = ''.join(title1).encode('latin1').decode('gbk')
                    else:
                        item['title'] = []
                except Exception as e:
                    print e

                # try:
                #     bid_result = re.findall(r'<td valign="\w+" width="387">\r\n.*0px">(.*)<o', s1)[1:]
                #     item_number = re.findall(r'<td valign="center" width="158">\r\n.*0px">(.*)<o', s1)[1:]
                #     bid_winner = {}
                #     for i in range(len(item_number)):
                #         bid_winner[item_number[i]] = bid_result[i].encode('latin1').decode('gbk')
                #     item['bid_winner'] = bid_winner
                # except Exception as e:
                #     print e
                # 
                # try:
                #     tender_number = re.findall(r'\xd5\xd0\xb1\xea\xb1\xe0\xba\xc5\xa3\xba(.{0,30}?) <', s1)
                #     tender_number1 = re.findall(r'\xcf\xee\xc4\xbf\xb1\xe0\xba\xc5\xa3\xba(.{0,30})<', s1)
                #     if tender_number:
                #         item['tender_number'] = ''.join(tender_number)
                #     elif tender_number1:
                #         item['tender_number'] = ''.join(tender_number1)
                #     else:
                #         item['tender_number'] = []
                # except Exception as e:
                #     print e
                #
                # try:
                #     contents = []
                #     all_content = re.findall(r'<p style="TEXT-JUSTIFY: inter-ideograph; TEXT-ALIGN: justify; LINE-HEIGHT: 2.2; MARGIN-TOP: 0px; TEXT-INDENT: 2em; MARGIN-BOTTOM: 0px">(.*?)<', s1)
                #     for i in all_content:
                #         contents.append(i.encode('latin1').decode('gbk'))
                #     item['tendering_agency'] = contents[1].replace(u'�б������','')
                #     item['owner'] = contents[2].replace(u'ҵ����','')
                #     item['public_time'] = contents[3].replace(u'��������ʾʱ�䣺','')
                #     item['industry'] = contents[4].replace(u'������ҵ��','')
                #     item['project_name'] = contents[5].replace(u'��Ŀ���ƣ�','')
                # except Exception as e:
                #     print e
                yield item
